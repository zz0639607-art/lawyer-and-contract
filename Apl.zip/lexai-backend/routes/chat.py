"""
routes/chat.py
POST /api/chat  —  AI 律师对话（多轮）
"""
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from services.gemini import call_gemini

router = APIRouter()


# ── 请求体 ──────────────────────────────────────────────
class Message(BaseModel):
    role:    str   # "user" | "assistant"
    content: str

class ChatRequest(BaseModel):
    message:  str = Field(..., min_length=1)
    history:  list[Message] = Field(default_factory=list)
    language: str = Field(default="English")


# ── 响应体 ──────────────────────────────────────────────
class ChatResponse(BaseModel):
    reply: str


# ── System Prompt ────────────────────────────────────────
def build_chat_prompt(message: str, history: list[Message], language: str) -> str:
    system = f"""You are LexAI, a friendly and knowledgeable AI legal assistant.
You help people understand contracts, legal terms, and general legal concepts.
You are NOT a licensed attorney. Always remind users to consult a qualified professional
for important legal decisions.

Rules:
- Respond entirely in {language}.
- Use plain, clear language.
- Use bullet points when listing multiple items.
- Keep responses concise and actionable.
- Never provide specific legal advice — provide general legal information only.
"""

    # Build conversation history string
    history_str = ""
    for msg in history[-10:]:   # keep last 10 turns to avoid token overflow
        role_label = "User" if msg.role == "user" else "LexAI"
        history_str += f"{role_label}: {msg.content}\n"

    return f"{system}\n\nConversation so far:\n{history_str}\nUser: {message}\nLexAI:"


# ── Route ────────────────────────────────────────────────
@router.post("/chat", response_model=ChatResponse)
async def chat(req: ChatRequest):
    prompt = build_chat_prompt(req.message, req.history, req.language)

    try:
        reply = await call_gemini(prompt, max_tokens=1000, temperature=0.5)
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"AI service error: {str(e)}")

    return ChatResponse(reply=reply.strip())
