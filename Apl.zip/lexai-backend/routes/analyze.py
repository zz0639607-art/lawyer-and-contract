"""
routes/analyze.py
POST /api/analyze  —  合同分析，返回 4 模块结构化报告
"""
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from services.gemini import call_gemini_json

router = APIRouter()


# ── 请求体 ──────────────────────────────────────────────
class AnalyzeRequest(BaseModel):
    contract_text: str = Field(..., min_length=50, description="合同原文")
    contract_type: str = Field(default="General Contract")
    jurisdiction:  str = Field(default="International")
    user_role:     str = Field(default="General / Unknown")
    report_lang:   str = Field(default="English")


# ── 响应体 ──────────────────────────────────────────────
class ClauseRow(BaseModel):
    clause:     str
    risk:       str          # 🔴 / 🟡 / 🟢
    implication: str

class RedlineItem(BaseModel):
    clause_name: str
    original:    str
    revised:     str
    talk_track:  str

class AnalyzeResponse(BaseModel):
    risk_level:          str          # Red / Yellow / Green
    risk_pct:            int          # 0-100
    contract_match:      str
    executive_summary:   str
    module2_rows:        list[ClauseRow]
    module3_items:       list[RedlineItem]
    module4_date_flag:   str
    module4_crossborder: str


# ── System Prompt ────────────────────────────────────────
SYSTEM_PROMPT = """You are LexAI, an elite international legal AI and contract analysis specialist.
Your target users are global freelancers, remote workers, and SMBs.
Your tone is professional, legally precise, clear, and actionable.

CONTRACT DETAILS:
- Jurisdiction:    {jurisdiction}
- Contract_Type:   {contract_type}
- User_Role:       {user_role}
- Report Language: {report_lang}

CORE DIRECTIVES:
1. Legal Alignment: Adapt analysis to {jurisdiction} legal system (Common Law vs Civil Law).
   Cite specific regional laws (GDPR/CCPA for privacy, local labour laws for employment) where risks occur.
2. Risk Identification: Scan for: Non-compete, Governing Law, Arbitration, Data Privacy,
   Force Majeure, Indemnity, Intellectual Property.
3. PII Safety: Do NOT echo any SSN, IBAN, passport numbers, or other sensitive PII.

RESPOND WITH ONLY A VALID JSON OBJECT — no markdown fences, no explanation outside the JSON.
Use this exact structure:
{{
  "risk_level": "Red|Yellow|Green",
  "risk_pct": <integer 0-100>,
  "contract_match": "<one sentence confirming or flagging contract_type + jurisdiction compatibility>",
  "executive_summary": "<2-3 sentence overall assessment>",
  "module2_rows": [
    {{ "clause": "<name>", "risk": "🔴|🟡|🟢", "implication": "<legal implication for {user_role}>" }}
  ],
  "module3_items": [
    {{
      "clause_name": "<name of risky clause>",
      "original":    "<excerpt max 60 words>",
      "revised":     "<exact legally-sound replacement text>",
      "talk_track":  "<one polite professional sentence to send to counterparty>"
    }}
  ],
  "module4_date_flag":   "<date/currency format ambiguity, or 'None detected'>",
  "module4_crossborder": "<tax withholding or trade compliance warning, or 'None applicable'>"
}}

Rules:
- Respond entirely in {report_lang}.
- Only include 🔴 and 🟡 items in module3_items.
- Cite real laws only. No hallucinations.
- Disclaimer will be appended separately — do not include it.

CONTRACT TEXT:
---
{contract_text}
---"""


# ── Route ────────────────────────────────────────────────
@router.post("/analyze", response_model=AnalyzeResponse)
async def analyze_contract(req: AnalyzeRequest):
    # Truncate to avoid token limits
    text_snippet = req.contract_text[:4500]

    prompt = SYSTEM_PROMPT.format(
        jurisdiction=req.jurisdiction,
        contract_type=req.contract_type,
        user_role=req.user_role,
        report_lang=req.report_lang,
        contract_text=text_snippet,
    )

    try:
        data = await call_gemini_json(prompt, max_tokens=2500)
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"AI service error: {str(e)}")

    # Validate & sanitize
    try:
        return AnalyzeResponse(
            risk_level          = data.get("risk_level", "Yellow"),
            risk_pct            = int(data.get("risk_pct", 50)),
            contract_match      = data.get("contract_match", ""),
            executive_summary   = data.get("executive_summary", ""),
            module2_rows        = [ClauseRow(**r) for r in data.get("module2_rows", [])],
            module3_items       = [RedlineItem(**i) for i in data.get("module3_items", [])],
            module4_date_flag   = data.get("module4_date_flag", "None detected"),
            module4_crossborder = data.get("module4_crossborder", "None applicable"),
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Response parsing error: {str(e)}")
