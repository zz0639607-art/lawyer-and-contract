"""
main.py
LexAI Backend — FastAPI 主程序
启动: uvicorn main:app --reload
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from routes.analyze import router as analyze_router
from routes.chat    import router as chat_router

# ── App ──────────────────────────────────────────────────
app = FastAPI(
    title="LexAI API",
    description="AI-powered contract analysis and legal assistant backend.",
    version="1.0.0",
    docs_url="/docs",       # Swagger UI: http://localhost:8000/docs
    redoc_url="/redoc",     # ReDoc:      http://localhost:8000/redoc
)

# ── CORS ─────────────────────────────────────────────────
# 开发阶段允许所有来源；上线后换成你的真实域名
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],        # 上线后改为: ["https://yourdomain.com"]
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Routers ───────────────────────────────────────────────
app.include_router(analyze_router, prefix="/api", tags=["Contract Analysis"])
app.include_router(chat_router,    prefix="/api", tags=["AI Lawyer Chat"])


# ── Health Check ─────────────────────────────────────────
@app.get("/", tags=["Health"])
async def root():
    return {
        "status": "ok",
        "service": "LexAI API",
        "version": "1.0.0",
        "endpoints": {
            "analyze": "POST /api/analyze",
            "chat":    "POST /api/chat",
            "docs":    "GET  /docs",
        },
    }

@app.get("/health", tags=["Health"])
async def health():
    return {"status": "healthy"}
